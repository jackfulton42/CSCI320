#include "kernel/pstat.h"
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc, char const *argv[])
{
    struct pstat ps;
    getpinfo(&ps);

    for(int i = 0; i < NPROC; i++)
    {
        if(ps.inuse[i])
        {
            printf("pid: %d, tickets: %d ", ps.pid[i], ps.tickets[i]);
            printf("ticks: %d\n", ps.ticks[i]);
        }
    }

    return 0;
}
