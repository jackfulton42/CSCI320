#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#include "common.h"
#include "common_threads.h"
#include "zemaphore.h"

//Zem_t mutex;
Zem_t Fork[20];
int maxPhils; //Number of Philosophers


int left(int p)
{
    return p;
}

int right(int p)
{
    return (p + 1) % maxPhils;
}

void getForks(int p)
{
    Zem_wait(&Fork[left(p)]);
    Zem_wait(&Fork[right(p)]);
}

void putForks(int p)
{
    Zem_post(&Fork[left(p)]);
    Zem_post(&Fork[right(p)]);
}

void *leftFirst(void *arg)
{
    //Lets me have access to the number of which Philosopher is here
    long long int value = (long long int) arg;
    int numPhil = (int) value;

    //Process of thinking and eating
    int count = 0;
    while(1)
    {
        count++;
        sleep(1);
        getForks(numPhil);
        if(count == 5)
        {
            //printf("Philosopher #%d is grabbing forks\n", numPhil);
            count = 0;
        }
        sleep(1);
        putForks(numPhil);   
    }

    return NULL;
}

int main()
{
    printf("How many philosophers are dining?\n");
    scanf("%d", &maxPhils);

    //Initializes the forks to 1
    for(int i = 0; i < maxPhils; i++)
    {
        Zem_init(&Fork[i], 1);
    }

    //Creates maxPhils instances of dining
    pthread_t child;
    for(int j = 0; j < maxPhils; j++)
    {
        long long int i = j;
        Pthread_create(&child, NULL, leftFirst, (void *) i);
    }

    Pthread_join(child, NULL);

    return 0;
}