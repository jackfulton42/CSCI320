#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#include "common.h"
#include "common_threads.h"
#include "zemaphore.h"

int barberChair;
Zem_t waitingRoom;
Zem_t mutex;
Zem_t cut;


void giveHaircut()
{
    //printf("Barber giving haircut\n");
    sleep(1);
    Zem_post(&cut);
}

//If the barber chair is unoccupied, the barber sleeps
//Once it becomes occupied, the barber does their thing
void *work()
{
    while(1)
    {
        if(barberChair > 0)
        {
            //printf("Barber sleeping\n");
            sleep(1);
        }
        else
        {
            giveHaircut();
        }
    }
}

void getHaircut(int customer)
{
    Zem_wait(&cut);
    sleep(1);
    barberChair++;
    printf("Customer #%d got their haircut.\n", customer);
}

void *wait(void *arg)
{
    long long int value = (long long int) arg;
    int customerNum = (int) value;

    //Barber Chair = 0 when all are taken
    if(barberChair == 0)
    {
        Zem_wait(&waitingRoom);
        printf("Customer #%d is in the waiting room.\n", customerNum);

        while(barberChair == 0)
        {
            
        }

        Zem_wait(&mutex);

        printf("Customer #%d is now in a barber's chair.\n", customerNum);
        barberChair--;
        Zem_post(&waitingRoom);
        getHaircut(customerNum);

        Zem_post(&mutex);
    }
    else
    {
        Zem_wait(&mutex);
        
        barberChair--;
        printf("Customer #%d is now in a barber's chair.\n", customerNum);
        getHaircut(customerNum);

        Zem_post(&mutex);
    }

}

int main()
{
    //Sets the number of barber chairs and waiting room chairs
    printf("How many barber chairs are there?\n");
    scanf("%d", &barberChair);
    
    Zem_init(&waitingRoom, 5);
    Zem_init(&mutex, barberChair);
    Zem_init(&cut, (barberChair-1));

    pthread_t barber;
    for(int x = 0; x < barberChair; x++)
    {
        Pthread_create(&barber, NULL, work, 0);
    }

    pthread_t customer;
    for(int j = 0; j < 9; j++)
    {
        long long int i = j;
        Pthread_create(&customer, NULL, wait, (void *) i);
    }


    Pthread_join(customer, NULL);
    Pthread_join(barber, NULL);
    

    return 0;
}